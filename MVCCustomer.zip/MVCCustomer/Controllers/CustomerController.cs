﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Net;
using MVCCustomer.Models;
using System.Data;



namespace MVCCustomer.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        private readonly CustomerModelDbContext db = new CustomerModelDbContext();

        [HttpGet]
        public ActionResult Index( )
        {
          
            return View(db.Customers.ToList());
        }


        [HttpGet]
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customers cus = db.Customers.Find(id);
            if (cus == null)
            {
                return HttpNotFound();
            }
            return View(cus);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Customers cus)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cus).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cus);
        }

        [HttpGet]
        public ActionResult Create()
        {

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Customers postCustInfo)
        {
            if (ModelState.IsValid)
            {

                if (db.Customers.Any(o => o.CustomerID == postCustInfo.CustomerID))
                { 
                   var emptyCus  = new Customers();

                    return View(emptyCus);
                }
                else
                {
                    db.Customers.Add(postCustInfo);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            return View();
        }

       
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

           
            Session["delPK"] = id;
            Customers cus = db.Customers.Find(id);
            if (cus == null)
            {
                return HttpNotFound();  
            }
            return View(cus);
        }



        [HttpPost]
        public ActionResult DeleteConfirmed()
        {
            if ((Session["delPK"].ToString() != "") || (Session["delPK"] != null))
            { Customers cus = db.Customers.Find(Session["delPK"]);

                db.Customers.Remove(cus);
                db.SaveChanges();
                Session["delPK"] = null;
                return RedirectToAction("Index");
                
            }
            return View();
        }


        
    }
}