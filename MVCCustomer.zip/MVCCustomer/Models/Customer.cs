﻿using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System;
using System.Linq;
using MVCCustomer;

namespace MVCCustomer.Models
{
    public  class Customers
    {

        [Required(ErrorMessage = "Please enter customer ID")] 
        public string CustomerID { get; set; }
      
        [Required(ErrorMessage = "Pleae enter company name")]
        public string CompanyName { get; set; }

        public string ContactName { get; set; }

        public string Address { get; set; }
        public string City { get; set; }
       
        public string Country { get; set; }
        public string Phone { get; set; }
        //public string Fax { get; set; }
    }


}


